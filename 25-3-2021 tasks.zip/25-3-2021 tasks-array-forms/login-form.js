//login form function with params
function login(user, pw) {
    if (user == 'akshay' && pw == 'akshay123') {
        alert('valid user');
        console.log(user, pw);
    } else {
        alert('Please check user name and password');
    }
}
login('akshay', 'akshay123'); /*true*/
login('ak', 'ash'); /*false*/