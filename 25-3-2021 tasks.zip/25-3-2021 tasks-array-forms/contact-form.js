function contact(name, number, message) {
    if (name == 'akshay' && number == 123456789) {
        alert('Message sent. check console for output');
        console.log(name, number, message);
    } else {
        alert('please fill correct name and number');
    }
}
contact('akshay', 123456789, 'hi how are u?'); /*true*/
contact('aks', 'abcd', 'xyz'); /*false*/