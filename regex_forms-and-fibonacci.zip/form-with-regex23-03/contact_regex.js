function validate() {
    var name = document.getElementById('fname').value;
    var number = document.getElementById('num').value;
    var email = document.getElementById('mail').value;
    var message = document.getElementById('msg').value;

    if (name == "" || number == "" || email == "" || message == "") {
        alert("Please enter all fields");
    }
}

function validateName() {
    var regex = /^[A-Za-z]+$/;
    let name = document.getElementById('fname').value;
    // console.log(name.match(regex));
    if (name.match(regex)) {
        document.getElementById('error_name').innerHTML = "";
        document.getElementById('fname').style.border = "2px solid green";
    } else {
        document.getElementById('error_name').innerHTML = "Please enter valid Name";
        document.getElementById('fname').style.border = "2px solid red";
    }
}

function validateNumber() {

    let number = document.getElementById('num').value;
    var regex2 = /^\d{10,12}$/;
    // console.log(number.match(regex2));
    if (number.match(regex2)) {
        document.getElementById('error_phone').innerHTML = "";
        document.getElementById('num').style.border = "2px solid green";


    } else {
        document.getElementById('error_phone').innerHTML = "Please enter valid mobile number";
        document.getElementById('num').style.border = "2px solid red";

    }
}

function validateEmail() {
    var regex3 = /\S+@\S+\.\S+/;
    let email = document.getElementById('mail').value;
    if (regex3.test(email)) {
        document.getElementById('error_email').innerHTML = "";
        document.getElementById('mail').style.border = "2px solid green";

    } else {
        document.getElementById('error_email').innerHTML = "Please enter valid email";
        document.getElementById('mail').style.border = "2px solid red";

    }

}

function validatePw() {
    var regex4 = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
    let password = document.getElementById('pw').value;
    if (regex4.test(password)) {
        document.getElementById('error_pw').innerHTML = "";
        document.getElementById('pw').style.border = "2px solid green";

    } else {
        document.getElementById('error_pw').innerHTML = "Password should contain min 6 characters, one number, one special character ";
        document.getElementById('pw').style.border = "2px solid red";

    }
}